# ACME.studio Lading Page
Landing page of the UnicoMotriz project. Focused on solving the lack of organization by managing the maintenance of the owners' vehicles and providing customization options through the information of workshops that provide this service.

Target segments:
- People who own at least one vehicle of their own over 18 years of age.

- Mechanical workshops located in Lima that provide technical service for automobiles and personalization of them.


Autores:

- Jorge Luis Juan de Dios Apaza

- Bryan Rodolfo Ore Areche

- Diego Gianfranco Calle Huaman

- Keni Abel Sánchez Villogas

- Sheyla Samira Pastor Ccasani